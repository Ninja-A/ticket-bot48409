const express = require('express');
const app = express();
const { Client, Collection } = require('discord.js');
const fs = require('fs');

const client = new Client({
    partials: ["MESSAGE", "CHANNEL", "REACTION"],
    intents: 32767,
});

module.exports = client;

const token = "OTU2ODc3MTY0NzU2NzQyMTQ0.G342Ts.VtuOIeD3b_Z7YiYg34WGiKkbxX42Vt7EmxE9kI";

client.on("ready", () => {
    console.log(`✅ Palmer State Roleplay`);
    console.log(`✅ Logged in as ${client.user.tag}`);
    client.user.setActivity("Palmer State Roleplay", { type: "PLAYING" });
});

// New collections
client.commands = new Collection();
client.aliases = new Collection();
client.events = new Collection();
client.slashCommands = new Collection();
client.categories = fs.readdirSync('./commands');

// Load handlers
['command', 'slashCommand'].forEach((handler) => {
    require(`./handler/${handler}`)(client);
});

// Express Web Server Fix
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    const replitUrl = `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.dev/`;
    console.log(`🌍 Try accessing your bot here: ${replitUrl}`);
});

app.get('/', (req, res) => {
    res.send(`<h2>PS:RP Ticket Bot is alive!</h2>`);
});

// Keep bot alive (Use this if UptimeRobot isn’t working)
setInterval(() => {
    require('node-fetch')(`https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.dev/`).catch(err => console.log("Ping failed"));
}, 5 * 60 * 1000); // Every 5 minutes

// Login bot
client.login(token);