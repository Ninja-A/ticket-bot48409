const { Client, Intents, MessageEmbed, MessageActionRow, MessageButton, MessageAttachment, Modal, TextInputComponent } = require('discord.js');
const db = require('quick.db');
const discordTranscripts = require('discord-html-transcripts');
const moment = require('moment');
const client = require('..');

const allowedRoleIDs = ['1349447904154222716'];
const staffRoleIDs = ['1348746621030109245', '1349067185427058748'];

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;
    let ticketData = db.fetch(`ticket-${interaction.channel.id}_${interaction.guild.id}`);
    if (!ticketData) return;

    if (interaction.customId === 'claim-ticket') {
        if (ticketData.closed) return;
        if (ticketData.user === interaction.user.id) return;
        if (!interaction.member.roles.cache.some(role => allowedRoleIDs.includes(role.id))) return;

        db.set(`ticket-${interaction.channel.id}_${interaction.guild.id}.claimedBy`, interaction.user.id);

        try {
            const ticketUser = await interaction.guild.members.fetch(ticketData.user).catch(() => null);
            if (ticketUser) {
                await interaction.channel.permissionOverwrites.edit(ticketUser, {
                    SEND_MESSAGES: true,
                    VIEW_CHANNEL: true,
                });
            }
            await interaction.channel.permissionOverwrites.edit(interaction.user, {
                SEND_MESSAGES: true,
                VIEW_CHANNEL: true,
            });
            for (const roleID of staffRoleIDs) {
                const role = interaction.guild.roles.cache.get(roleID);
                if (role) {
                    await interaction.channel.permissionOverwrites.edit(role, {
                        VIEW_CHANNEL: true,
                        SEND_MESSAGES: false,
                        ADD_REACTIONS: false,
                        MANAGE_MESSAGES: false,
                    });
                }
            }
            const messages = await interaction.channel.messages.fetch({ limit: 10 });
            const ticketMessage = messages.find(msg => msg.components.length > 0);
            if (ticketMessage) {
                const newComponents = [
                    new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('unclaim-ticket')
                            .setLabel('Unclaim Ticket')
                            .setStyle('DANGER')
                    )
                ];
                await ticketMessage.edit({ components: newComponents });
            }
        } catch (error) {
            console.error(`Error updating ticket permissions: ${error.message}`);
        }
    }

    if (interaction.customId === 'unclaim-ticket') {
        if (!ticketData || ticketData.closed) return;
        if (ticketData.claimedBy !== interaction.user.id) return;

        db.delete(`ticket-${interaction.channel.id}_${interaction.guild.id}.claimedBy`);
        interaction.channel.permissionOverwrites.delete(interaction.user.id);
        staffRoleIDs.forEach(roleID => {
            interaction.channel.permissionOverwrites.edit(roleID, {
                VIEW_CHANNEL: true,
                SEND_MESSAGES: true,
                ADD_REACTIONS: true,
                MANAGE_MESSAGES: true,
            });
        });
        interaction.channel.permissionOverwrites.edit(ticketData.user, {
            SEND_MESSAGES: true,
            VIEW_CHANNEL: true,
        });
        const messages = await interaction.channel.messages.fetch({ limit: 10 });
        const ticketMessage = messages.find(msg => msg.components.length > 0);
        if (ticketMessage) {
            const newComponents = [
                new MessageActionRow().addComponents(
                    new MessageButton()
                        .setCustomId('claim-ticket')
                        .setLabel('Claim Ticket')
                        .setStyle('SUCCESS')
                )
            ];
            await ticketMessage.edit({ components: newComponents });
        }
    }
});


// Automatically allow staff roles to see all tickets & ensure ticket creator always has access
client.on('channelCreate', async channel => {
    if (!channel.name.startsWith('ticket-')) return;

    let ticketData = db.fetch(`ticket-${channel.id}_${channel.guild.id}`);
    if (!ticketData) return;

    // Ensure ticket creator has access
    channel.permissionOverwrites.edit(ticketData.user, {
        SEND_MESSAGES: true,
        VIEW_CHANNEL: true,
    });

    // Give staff roles initial access
    staffRoleIDs.forEach(roleID => {
        channel.permissionOverwrites.edit(roleID, {
            VIEW_CHANNEL: true,
            SEND_MESSAGES: true,
            ADD_REACTIONS: true,
            MANAGE_MESSAGES: true,
        });
    });

    console.log(`Updated permissions for staff and ticket creator in: ${channel.name}`);
});

// Define category IDs
const ticketCategories = {
    'general-support': '1349449268838010971',
    'bug-report': '1349449606852776087',
    'staff-report': '1349449750293905470'
};

// Define role access per ticket type
const ticketAccessRoles = {
    'general-support': ['1244930361763299379'],
    'bug-report': ['1247192691977097299'],
    'staff-report': ['1349447904154222716']
};

// Define global staff roles (all tickets)
const staffRoles = [];

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() && !interaction.isSelectMenu()) return;

    let Data = db.fetch(`ticketCount_${interaction.guildId}`);
    if (Data == null) Data = 0;

    // Handle ticket type selection
    if (interaction.isSelectMenu() && interaction.customId === 'ticket-type') {
        const ticketType = interaction.values[0];

        // Ensure the ticket type exists in our mapping
        if (!ticketCategories[ticketType]) {
            return interaction.reply({ content: 'Invalid ticket type.', ephemeral: true });
        }

        await interaction.reply({ content: 'Creating ticket, please standby...', ephemeral: true });

        // Ticket settings
        let ticketPrefix = 'ticket';
        let ticketColor = '#3498db';
        let welcomeTitle = 'Ticket Support';

        if (ticketType === 'general-support') {
            ticketPrefix = 'gs';
            ticketColor = '#3498db';
            welcomeTitle = 'General Support';
        } else if (ticketType === 'bug-report') {
            ticketPrefix = 'br';
            ticketColor = '#e74c3c';
            welcomeTitle = 'Bug Report';
        } else if (ticketType === 'staff-report') {
            ticketPrefix = 'sr';
            ticketColor = '#f1c40f';
            welcomeTitle = 'Staff Report';
        }

        // Set up permission overwrites
        let permissionOverwrites = [
            {
                id: interaction.user.id,
                allow: ['SEND_MESSAGES', 'VIEW_CHANNEL'],
            },
            {
                id: interaction.guild.roles.everyone,
                deny: ['VIEW_CHANNEL'],
            },
            // Grant access to specific roles for this ticket type
            ...ticketAccessRoles[ticketType].map(roleId => ({
                id: roleId,
                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
            })),
            // Grant access to global staff roles
            ...staffRoles.map(roleId => ({
                id: roleId,
                allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
            })),
        ];

        try {
            // Create the ticket channel
            const ticket = await interaction.guild.channels.create(`${ticketPrefix}-${interaction.user.username}-${Data}`, {
                parent: ticketCategories[ticketType], 
                permissionOverwrites: permissionOverwrites,
                type: 'text',
            });

            db.add(`ticketCount_${interaction.guildId}`, 1);
            db.set(`ticket-${ticket.id}_${interaction.guild.id}`, {
                user: interaction.user.id,
                closed: false,
                ticketType: ticketType
            });

            await interaction.editReply({ content: `Ticket created: ${ticket}`, ephemeral: true });

            // Send Welcome Message
            const welcomeTicket = new MessageEmbed()
                .setAuthor({ name: welcomeTitle, iconURL: client.user.displayAvatarURL() })
                .setDescription('The assigned staff team will be with you shortly.\nPlease send all issues/questions with proper evidence in this ticket.')
                .setColor(ticketColor)
                .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL() });

            const closeButton = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('close-ticket')
                        .setLabel('Close')
                        .setEmoji('🔒')
                        .setStyle('SECONDARY'),
                    new MessageButton()
                        .setCustomId('claim-ticket')
                        .setLabel('Claim Ticket')
                        .setEmoji('📝')
                        .setStyle('PRIMARY'),
                );

            // Get the role IDs that should be mentioned
            const roleMentions = ticketAccessRoles[ticketType].map(roleId => `<@&${roleId}>`).join(' ');

            // Send the message with role ping
            await ticket.send({ 
                content: `${roleMentions} ${interaction.user}`,
                embeds: [welcomeTicket], 
                components: [closeButton] 
            });

            console.log(`✅ Ticket created: ${ticket.id}`);
        } catch (error) {
            console.error(`❌ Failed to create ticket: ${error.message}`);
            await interaction.editReply({ content: 'Error creating ticket. Please contact reactor_tech.', ephemeral: true });
        }
    }
});


client.on('interactionCreate', async (interaction) => {  // ✅ Ensure it's async
    if (!interaction.isButton()) return;

    const ticketData = db.fetch(`ticket-${interaction.channel.id}_${interaction.guild.id}`);

    // Close the ticket
    if (interaction.customId === 'close-ticket') {
        if (!ticketData || ticketData.closed) {
            return interaction.reply({ content: 'This ticket is already closed', ephemeral: true });
        }

        const closeTicket = new MessageEmbed()
            .setDescription(`Ticket Closed by ${interaction.user}`);

        const closeButton = {
            'type': 1,
            'components': [
                {
                    'type': 2,
                    'style': 'SECONDARY',
                    'custom_id': 'transcript',
                    'emoji': '📑',
                    'label': 'Transcript',
                },
                {
                    'type': 2,
                    'style': 'SECONDARY',
                    'custom_id': 'open',
                    'emoji': '🔓',
                    'label': 'Open',
                },
                {
                    'type': 2,
                    'style': 'SECONDARY',
                    'custom_id': 'delete',
                    'emoji': '⛔',
                    'label': 'Delete',
                },
            ]
        };

        await interaction.reply({ embeds: [closeTicket], components: [closeButton] });
        await interaction.channel.permissionOverwrites.edit(ticketData.user, {
            SEND_MESSAGES: false,
            VIEW_CHANNEL: false,
        });

        db.set(`ticket-${interaction.channel.id}_${interaction.guild.id}.closed`, true);
    }

    // Open the ticket after it's been closed
    if (interaction.customId === 'open') {
        if (!ticketData || !ticketData.closed) {
            return interaction.reply({ content: 'This ticket is already open', ephemeral: true });
        }

        const reopen = new MessageEmbed()
            .setDescription(`Ticket Opened by ${interaction.user}`);

        await interaction.reply({ embeds: [reopen] });
        await interaction.channel.permissionOverwrites.edit(ticketData.user, {
            SEND_MESSAGES: true,
            VIEW_CHANNEL: true,
        });

        db.set(`ticket-${interaction.channel.id}_${interaction.guild.id}.closed`, false);
    }

    // Delete the ticket after it's been closed
    if (interaction.customId === 'delete') {
        await interaction.reply({
            embeds: [
                new MessageEmbed().setDescription('Ticket will be deleted in a few seconds.')
            ]
        });

        setTimeout(() => {
            interaction.channel.delete();
        }, 5000);

        db.delete(`ticket-${interaction.channel.id}_${interaction.guild.id}`);
    }

    // Generate and send a transcript of the ticket
    if (interaction.customId === 'transcript') {
        const transcriptType = db.fetch(`transcriptType_${interaction.guild.id}`);
        const transcriptChannel = db.fetch(`ticketTranscript_${interaction.guild.id}`);

        if (transcriptType === 'html') {
            const attachment = await discordTranscripts.createTranscript(interaction.channel);
            await client.channels.cache.get(transcriptChannel).send({
                content: `**Ticket Transcript - ${interaction.channel.name}**`,
                files: [attachment]
            });
            await interaction.reply({
                embeds: [
                    new MessageEmbed().setDescription(`Ticket transcript sent to <#${transcriptChannel}>!`)
                ]
            });
        } else if (transcriptType === 'text') {
            let messages = await interaction.channel.messages.fetch();
            messages = messages
                .map(m => moment(m.createdTimestamp).format("YYYY-MM-DD hh:mm:ss") + " | " + m.author.tag + ": " + m.cleanContent)
                .join("\n") || "No messages were in the ticket or failed logging transcript";

            const txt = new MessageAttachment(Buffer.from(messages), `transcript_${interaction.channel.id}.txt`);
            await client.channels.cache.get(transcriptChannel).send({
                content: `**Ticket Transcript - ${interaction.channel.name}**`,
                files: [txt]
            });
            await interaction.reply({
                embeds: [
                    new MessageEmbed().setDescription(`Ticket transcript sent to <#${transcriptChannel}>!`)
                ]
            });
        }
    }
});