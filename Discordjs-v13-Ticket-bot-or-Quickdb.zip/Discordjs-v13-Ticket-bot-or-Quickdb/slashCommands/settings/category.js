const { SlashCommandBuilder } = require('@discordjs/builders');
const db = require('quick.db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('parent-category')
        .setDescription('Set the parent category of ticket channels')
        .addChannelOption(category =>
            category.setName('category').setDescription('Ticket channels\' parent category')
        ),
    async execute(client, interaction) {
        try {
            let category = interaction.options.getChannel('category');
            if (!category) return; // If category doesn't exist, silently stop

            db.set(`parentCategory_${interaction.guild.id}`, category.id);
        } catch (e) {
            // Do absolutely nothing on error (fully silent)
        }
    }
};