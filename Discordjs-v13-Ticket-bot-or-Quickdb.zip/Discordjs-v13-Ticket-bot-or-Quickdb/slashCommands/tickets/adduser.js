
const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const db = require('quick.db');

module.exports = {
    data: new SlashCommandBuilder()
       .setName('add-user')
        .setDescription('Add a user to a ticket')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to add to the ticket')
                .setRequired(true)),
    async execute(client, interaction) {
        const targetUser = interaction.options.getUser('user');
        if (!targetUser) {
            return interaction.reply({ content: 'You must mention a user to add to the ticket.', ephemeral: true });
        }

        let ticketData = db.fetch(`ticket-${interaction.channel.id}_${interaction.guild.id}`);
        if (!ticketData || ticketData.closed) {
            return interaction.reply({ content: 'This ticket is already closed or does not exist.', ephemeral: true });
        }

        interaction.channel.permissionOverwrites.edit(targetUser.id, {
            SEND_MESSAGES: true,
            VIEW_CHANNEL: true,
        });

        return interaction.reply({ content: `**${targetUser.username}** has been added to the ticket!`, ephemeral: false });
    }
};
