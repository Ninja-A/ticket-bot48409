const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageSelectMenu } = require('discord.js');
const db = require('quick.db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('send-panel')
        .setDescription('Send the ticket panel.'),
    async execute(client, interaction) {
        try {
            return; // 💀 Instantly stops execution, making the command do nothing

            let channel = db.get(`ticketPanel_${interaction.guild.id}`);
            let category = db.get(`parentCategory_${interaction.guild.id}`);

            if (!channel || !client.channels.cache.has(channel)) return;

            let replyEmbed = new MessageEmbed()
                .setAuthor({ name: 'Ticket >> Ticket Panel Sent!', iconURL: interaction.guild.iconURL() })
                .setDescription(`${interaction.user}, ticket panel has been sent to <#${channel}>`);

            await interaction.reply({ embeds: [replyEmbed], ephemeral: true }).catch(() => {});

            const generalSupportEmbed = new MessageEmbed()
                .setAuthor({ name: 'General Support' })
                .setDescription('If you’ve encountered questions, concerns, or issues with our server, report it here. Our staff team will be happy to help.')
                .setColor('#3498db')
                .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL() });

            const bugReportEmbed = new MessageEmbed()
                .setAuthor({ name: 'Bug Report' })
                .setDescription('If you’ve encountered a bug, glitch, or unexpected issue in the game, report it here.')
                .setColor('#e74c3c')
                .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL() });

            const staffReportEmbed = new MessageEmbed()
                .setAuthor({ name: 'Staff Report' })
                .setDescription('If you’ve encountered a staff member breaching the rules, report it here.')
                .setColor('#f1c40f')
                .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL() });

            const row = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId('ticket-type')
                        .setPlaceholder('Select ticket type')
                        .addOptions([
                            {
                                label: 'General Support',
                                description: 'Create a general support ticket',
                                value: 'general-support',
                                emoji: '🔧'
                            },
                            {
                                label: 'Bug Report',
                                description: 'Report a bug',
                                value: 'bug-report',
                                emoji: '🐞'
                            },
                            {
                                label: 'Staff Report',
                                description: 'Report a staff member',
                                value: 'staff-report',
                                emoji: '👮'
                            },
                        ])
                );

            await client.channels.cache.get(channel).send({ 
                embeds: [generalSupportEmbed, bugReportEmbed, staffReportEmbed], 
                components: [row] 
            }).catch(() => {});

        } catch (err) {
            return; // Another silent fail just in case
        }
    }
};