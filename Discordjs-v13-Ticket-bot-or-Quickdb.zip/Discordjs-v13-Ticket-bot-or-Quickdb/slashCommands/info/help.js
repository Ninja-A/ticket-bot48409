const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Display all the commands of this bot.'),
	async execute(client, interaction) {
      let embed = new MessageEmbed()
      .setTitle(`PS:RP Ticket Bot Help Page`)
      .setDescription(`This help page shows all the command of this bot.\n\n\n**Slash Commands**\n\`ping\`\nReturns bot ping.\n\n\`parent-category\`\nSet the parent category of ticket channels (INACTIVE)\n\n\`send-channel\`\nSet the channel to send the ticket panel\n\n\`transcript-set\`\nSet the channel to send transcript & the type of transcript\n\n\`send-panel\`\nSend the ticket panel\n\n\`create\`\nCreate a new the ticket (INACTIVE)\n\n\`close\`\nClose the ticket (INACTIVE)\n\n\`open\`\nOpen the ticket (INACTIVE)\n\n\`delete\`\nDelete the ticket (INACTIVE)\n\n\`transcript\`\nSend the ticket transcript. (INACTIVE)\n\n\`staff-roles add\`\nAdd a role to the ticket staff list (INACTIVE)\n\n\`staff-roles remove\`\nRemove a role to the ticket staff list (INACTIVE)\n\n\`staff-roles list\`\nList all the ticket staff roles (INACTIVE)\n\n\`add-user\`\nAdd a user to a ticket`)
      .setFooter(`Palmer State Roleplay`)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 4096 }))
      interaction.reply({ embeds: [embed], ephemeral: true});
	}
};